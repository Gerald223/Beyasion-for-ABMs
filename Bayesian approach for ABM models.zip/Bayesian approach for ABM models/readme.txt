1. Programming language: Julia 1.7.

2. Enter the command "include('path+run_MacroABM.jl')" in Julia to run the simulator.

3. "MySMC" and "MacroABM" are the packages of SMC algorithm and ABM respectively (the default location is desktop, if other location, need to change the path in "run_MacroABM.jl").

4. The simulation result will be found in "MacroABM/save", and the file "smc.csv" will be generated when the program runs.