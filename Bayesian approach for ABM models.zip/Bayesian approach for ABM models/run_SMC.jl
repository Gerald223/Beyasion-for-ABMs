######################### SMC for Market-Reinvestment Model #####################
##load the Markov-Switching SV model
push!(LOAD_PATH,"/Users/wangqianchao/essay/SMC/code/MacroABM")
using MacroABM
##load the SMC package
push!(LOAD_PATH,"/Users/wangqianchao/essay/SMC/code/MySMC")
using MySMC, LinearAlgebra
using CSV, DataFrames, Printf,Tables
##simulation of SMC for agent-based model
for i = 1
   cd("/Users/wangqianchao/essay/SMC/code/MacroABM")
   theta = [0.5,2.0,0.5,0.5,0.5,0.1,0.1,0.1,0.5] #true value
   T = 50
   y = data_gen_DG(theta,T)
   #y = convert(Array{Float64,2},Matrix(CSV.read("save/data_abm.csv")))
   #T = size(y,1)
   println("\n Simulation with T = $(T).")
   N = 1000 #number of particles for SMC
   M = 800 #number of draws for kernel
   println("\n $(N) particles for SMC, $(M) draws for kernel.")
   ## define the likelihood function
   k = size(y,2)
   u = randn(T,k,M) #fix seed
   # define a new function
   loglike!(x::Vector{Float64}) = loglike_DG(x,y,M,u=u)
   ##initialize by drawing from the prior
   println("\n drawing from prior...\n")
   out = [drawprior_DG(y,M,u=u)  for j = 1:N]
   ##particles,logprior and loglikelihood
   n_params = length(out[1][1])
   particles = zeros(N, n_params);
   logprior = zeros(N);
   loglh = zeros(N);
   for j = 1:N
       particles[j,:] = out[j][1]
       logprior[j] = out[j][2]
       loglh[j] = out[j][3]
   end
   S_init = init_smc(particles,logprior,loglh,c=0.3)
   Sampler = smc(100,3.4,logprior_DG,loglike!,S_init,n_blocks=1,smcsa=100)
   ##save the posterior-mean
   post_means = CSV.read(savepath("smcmean.csv"))
   CSV.write(savepath("smc.csv"),post_means,append=true)
   println("\n Replication = $(i)")
end
