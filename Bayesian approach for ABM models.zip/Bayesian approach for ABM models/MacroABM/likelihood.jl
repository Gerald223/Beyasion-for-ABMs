function loglike_DG(θ::Vector{Float64},y::Matrix{Float64},N::Int;u=[])
    ##bound of parameters
    l_b = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    u_b = [4.0, Inf, 1.0, 1.0, 1.0, Inf, Inf, Inf, 1.0]
    if !prod(l_b .< θ .< u_b)
        return -Inf
    end
    #parameters setting
    a1,a2 = θ[1],θ[2]
    b1,b2 = θ[3],θ[4]
    γ,σ1,σ2,σ3,ρ = θ[5],θ[6],θ[7],θ[8],θ[9]
    ##simulate from the unconditional distribution of y
    T = size(y,1)
    ysim = zeros(T,3,N)
    for i in 1:N
        ysim[:,:,i] = if u==[]
                       data_gen_DG(θ,T)
                    else
                       data_gen_DG(θ,T,u=u[:,:,i])
                    end
    end
    ##unconditional density
    L = 0.0
    for t = 1:T
        h_y = 1.06*std(ysim[t,1,:])/N^0.2
        h_π = 1.06*std(ysim[t,2,:])/N^0.2
        h_r = 1.06*std(ysim[t,3,:])/N^0.2
        kernel = -0.5*(log(2*pi*h_y^2) .+(ysim[t,1,:].-y[t,1]).^2/h_y^2)
        kernel = kernel -0.5*(log(2*pi*h_π^2) .+(ysim[t,2,:].-y[t,2]).^2/h_π^2)
        kernel = kernel -0.5*(log(2*pi*h_r^2) .+(ysim[t,3,:].-y[t,3]).^2/h_r^2)
        mk = maximum(kernel)
        kernel .-= mk
        loglh = if isnan(sum(kernel))
                   -Inf
                else
                    log(mean(exp.(kernel))) + mk
                end
        L += loglh
    end
    return L
end
