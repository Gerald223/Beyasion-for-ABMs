#the behavioral macroeconomics model of De Grauwe(2012)
function data_gen_DG(theta::Vector{Float64},T::Int;u=[])
    ##true value
    a1,a2 = theta[1],theta[2] #-1/a2
    b1,b2 = theta[3],theta[4]
    #fixed parameters
    c1, c2, c3 = 2.0, 0.5, 0.5
    #c1, c2, c3 = 0.085, -0.162, 0.514
    γ = theta[5] #γ/10
    σ1,σ2,σ3 = theta[6],theta[7],theta[8]
    ρ = theta[9]
    #coefficient matrix
    C = [1 0 1/a2; -b2 1 0; -c2 -c1 1]
    ##observables
    Y = zeros(T+2,3)
    y = Y[:,1]
    π = Y[:,2]
    r = Y[:,3]
    Uf_y = (y[2]-0.0)^2  #time=1
    Uf_π = (π[2]-0.0)^2
    Ue_y = (y[2]-0.0)^2  #time=1
    Ue_π = (π[2]-0.0)^2
    for t = 3:(T+2)
        Py = exp(10*γ*Uf_y)/(exp(10*γ*Uf_y)+exp(10*γ*Ue_y))
        Pπ = exp(10*γ*Uf_π)/(exp(10*γ*Uf_π)+exp(10*γ*Ue_π))
        if u==[]
            y[t] = (a1*Py+1-a1)*y[t-1] +Pπ*π[t-1]/a2 +σ1*randn()
            π[t] = (b1*Pπ+1-b1)*π[t-1] +σ2*randn()
            r[t] = c3*r[t-1] +σ3*randn()
        else
            y[t] = (a1*Py+1-a1)*y[t-1] +Pπ*π[t-1]/a2 +σ1*u[t-2,1]
            π[t] = (b1*Pπ+1-b1)*π[t-1] +σ2*u[t-2,2]
            r[t] = c3*r[t-1] +σ3*u[t-2,3]
        end
        #solve the NK model
        obs = [y[t],π[t],r[t]]
        obs = inv(C)*obs
        y[t],π[t],r[t] = obs[1],obs[2],obs[3]
        #updating MSFE
        Uf_y = ρ*Uf_y + (y[t]-0.0)^2
        Uf_π = ρ*Uf_π + (π[t]-0.0)^2     #fundamental
        Ue_y = ρ*Ue_y + (y[t]-y[t-2])^2
        Ue_π = ρ*Ue_π + (π[t]-π[t-2])^2 #extrapolative
    end
    Y[:,1] = y
    Y[:,2] = π
    Y[:,3] = r
    return Y[3:(T+2),:]
end
