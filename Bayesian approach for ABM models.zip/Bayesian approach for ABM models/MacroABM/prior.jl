﻿##logprior of BH model
gamma(alpha) = 1/(pdf(Gamma(alpha),1)*exp(1))
function logprior_DG(θ::Vector{Float64})
    y = pdf(Gamma(2,2),θ[2])
    y += pdf(Beta(2,2),θ[5])
    ν = 2
    τ = 0.1
    y += log(2)-log(gamma(ν/2))+(ν/2)*log(ν*τ^2/2)-((ν+1)/2)*log(θ[6]^2)-ν*τ^2/(2*θ[6]^2)
    y += log(2)-log(gamma(ν/2))+(ν/2)*log(ν*τ^2/2)-((ν+1)/2)*log(θ[7]^2)-ν*τ^2/(2*θ[7]^2)
    y += log(2)-log(gamma(ν/2))+(ν/2)*log(ν*τ^2/2)-((ν+1)/2)*log(θ[8]^2)-ν*τ^2/(2*θ[8]^2)
    return y
end
## draw from j'th dimension of parameter vector
function onedraw_DG()
    draw = zeros(9)
    draw[1] = rand(Uniform(0.0,4.0))
    draw[2] = rand(Gamma(2,2))
    draw[[3:4;9]] = rand(3)
    draw[5] = rand(Beta(2,2))
    ν = 2
    τ = 0.1
    draw[6] = sqrt(ν*(τ^2)^2/sum(randn(2).^2))
    draw[7] = sqrt(ν*(τ^2)^2/sum(randn(2).^2))
    draw[8] = sqrt(ν*(τ^2)^2/sum(randn(2).^2))
    return draw
end
## sampling from the prior distribution
function drawprior_DG(y::Matrix{Float64},M::Int;u=[])
	success = false
    prior_draw = []
    logprior = 0.0
    loglh = -Inf
    ## draw from prior distribution
	while !success
		prior_draw = onedraw_DG()
        # compute the loglikelihood of BH models
        logprior = logprior_DG(prior_draw)
        loglh = try
                   loglike_DG(prior_draw,y,M,u=u)
               catch
                   -Inf
               end
		# to avoid zero weights in the prior draws
		if loglh != -Inf
			success = true
		else
			success = false
		end
	end
    return prior_draw, logprior, loglh
end
