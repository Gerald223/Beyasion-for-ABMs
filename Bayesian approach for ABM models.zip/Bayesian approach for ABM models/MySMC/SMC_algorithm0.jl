"""
```
smc(n_Φ::Int,λ::Float64, pri::Function,lh::Function,
	         S::SMCSampler;n_blocks::Int=1,k::Int=2,
			 smcsa::Int=10,verbose::Symbol=:low)
```
### Arguments:
- n_Φ: number of SMC iterations
- λ: tempering power
- pri: log prior density
- lh: loglikelihood function
- S: the SMCSampler type containing particle draws and weights
- k: continue the SMC algorithm from k'th recursion
### Outputs
- S: final updated SMCSampler
### Overview
   Sequential Monte Carlo can be used in lieu of Random Walk Metropolis Hastings to
generate parameter samples from high-dimensional parameter spaces using sequentially
constructed proposal densities.
   The implementation here is based upon Edward Herbst and Frank Schorfheide's
2014 paper 'Sequential Monte Carlo Sampling for DSGE Models' and the code
accompanying their book 'Bayesian Estimation of DSGE Models'.
   SMC is broken up into three main steps:
- `Correction`: Reweight the particles from stage n-1 by defining "incremental weights",
                incweight, which gradually incorporate the likelihood function
				p(Y|θ(i,n-1)) into the particle weights.
- `Selection`: Resample the particles if the distribution of particles begins to degenerate,
               according to a tolerance level ESS < N/2. The current resampling technique
			   employed is systematic resampling.
- `Mutation`: Propagate particles {θ(i),W(n)} via block RWMH algorithm.
"""

function smc(n_Φ::Int,λ::Float64, pri::Function,lh::Function,
	         S::SMCSampler;n_blocks::Int=1,k::Int=2,smcsa::Int=1,
			 target::Float64=0.25,verbose::Symbol=:low)
    ##Set parameters of algorithm
    n_part = size(S.particles,1)
    n_params = size(S.particles,2)
    tempering_schedule = ((collect(1:1:n_Φ).-1)/(n_Φ-1)).^λ

    # SMC starts
	if VERBOSITY[verbose] >= VERBOSITY[:low]
	println("\n SMC starts .... \n")
	end
	##marginal likelihood
	zhat = zeros(n_Φ)
	##prior mean and std
	i = k-1
	weight = S.weights
	para = S.particles
	zhat[i] = sum(weight)   ##[0...0,1,0...0]->(k-1)'th recurison
	μ = weight'*para;
	σ = weight'*broadcast(-,para,μ).^2;
	σ = σ.^0.5;
	Φ = tempering_schedule[i];
    if VERBOSITY[verbose] >= VERBOSITY[:low]
		println("Recursion: $(i)/$(n_Φ), c: $(round(S.c,digits=4)) \n")
	    if VERBOSITY[verbose] >= VERBOSITY[:high]
		    for n=1:n_params
			    println("parameter$(n): $(μ[n]), $(σ[n])")
		    end
	    end
    end
	##save the prior draws
	if i % smcsa == 0
		save_file = savepath("smcsave1.csv")
		CSV.write(save_file,DataFrame(S.particles))
		save_file2 = savepath("smcsave2.csv")
		CSV.write(save_file2,DataFrame(x=S.weights,y=S.logprior,z=S.loglh))
		save_file3 = savepath("smcsave3.csv")
		CSV.write(save_file3,DataFrame(x=zhat))
		save_file4= savepath("smcsave4.csv")
		CSV.write(save_file4,DataFrame(x=[S.nresamp; S.c; S.accept]))
	end

    ##for block-updation of particles
    Block = rand(n_Φ, n_params)
    #RECURSION
    total_sampling_time = 0.0
    for i=k:n_Φ
        tic=time()
	   #------------------------------------
	   # (a) Correction
	   #------------------------------------
	   ##Incremental weights
	   incweight = (tempering_schedule[i] - tempering_schedule[i-1])*S.loglh
	   ##Update and normalize weights
	   S.weights = exp.(log.(S.weights)+incweight)  ##normalized_w*increment_w
       zhat[i] = sum(S.weights)
	   S.weights = S.weights/sum(S.weights)
	   ##Efficient sample size
	   ESS = 1/sum(S.weights .^2)
       @assert !isnan(ESS) "NaN in weights"
	   #------------------------------------
	   # (b) Selection
	   #------------------------------------
	   if ESS < n_part/2
	       id = systematic_resampling(S.weights)
           S.particles = S.particles[id, :]
		   S.logprior = S.logprior[id]
	       S.loglh = S.loglh[id]
	       S.weights= ones(n_part)./n_part
	       S.nresamp += 1
	   end
	   #------------------------------------
	   # (c) Mutation
	   #------------------------------------
       S.c = S.c *(0.95+0.10*exp(16*(S.accept-target))/(1+exp(16*(S.accept-target))))
       para = S.particles
       weight = S.weights # normalized weights
       μ = weight'*para
	   z = broadcast(-,para,μ)
       R_temp = (z.*weight)'*z
       R = (R_temp + R_temp')/2
	   ##particle mutation via block-rwmh
	   Φn = tempering_schedule[i]
       if S.parallel
           out = @sync @distributed (vcat) for j = 1:n_part
				   mutation_blockmh(S,pri,lh,Φn,R,Block[i,:],j, n_blocks=n_blocks)
			   end
	   else
		   out = [mutation_blockmh(S,pri,lh,Φn,R,Block[i,:],j, n_blocks=n_blocks)  for j=1:n_part]
	   end
	   ##update acceptance rate
       S.accept = mean(out.!=0)
	   para = S.particles;
	   weight = S.weights;
	   S.mdd += log(zhat[i])
	   μ = weight'*para;
	   σ = weight'*broadcast(-,para,μ).^2;
	   μ = μ';
	   σ = σ'.^0.5;
       ##timekeeping
	   toq=time()
       block_time = toq-tic
       total_sampling_time += block_time
       t1 = round(total_sampling_time/60,digits=2)
       expected_time_remaining_sec = (total_sampling_time/(i-k+1))*(n_Φ - i)
       t2 = round(t1 + expected_time_remaining_sec/60,digits=2)

       if VERBOSITY[verbose] >= VERBOSITY[:low]
		   str1 = "Recursion:$(i)/$(n_Φ), Time:$(t1)/$(t2) minutes, c:$(round(S.c,digits=4)), accept:$(round(S.accept,digits=4)),"
		   str2 = " ESS:$(round(ESS,digits=2))/$(n_part), resamples:$(S.nresamp), lnP(y|M):$(round(S.mdd,digits=2))"
           println(string(str1,str2))
           if VERBOSITY[verbose] >= VERBOSITY[:high]
			   for n=1:n_params
				   println("parameter$(n): $(μ[n]), $(σ[n])")
			   end
		   end
	   end
	   #------------------------------------
	   # Saving parameter draws
	   #------------------------------------
	   if i%smcsa == 0
		   save_file = savepath("smcsave1.csv")
		   CSV.write(save_file,DataFrame(S.particles))
		   save_file2 = savepath("smcsave2.csv")
		   CSV.write(save_file2,DataFrame(x=S.weights,y=S.logprior,z=S.loglh))
		   save_file3 = savepath("smcsave3.csv")
		   CSV.write(save_file3,DataFrame(x=zhat))
		   save_file4= savepath("smcsave4.csv")
		   CSV.write(save_file4,DataFrame(x=[S.nresamp; S.c; S.accept]))
	   end
    end #of SMC Recursions
    ##save posterior mean and std
	CSV.write(savepath("smcmean.csv"),DataFrame(μ'))
	CSV.write(savepath("smcstd.csv"),DataFrame(σ'))
end
