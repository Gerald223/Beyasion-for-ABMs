## filepath for SMCSampler
function savepath(file_name::AbstractString)
    path = "save"
    # Containing dir
    if !isdir(path)
        mkpath(path)
    end
    path = joinpath(path, file_name)
    return path
end
