mutable struct SMCSampler
    ## parallel computing
    parallel::Bool
    ## particle draws
    particles::Array{Float64,2}
    logprior::Array{Float64,1}
    loglh::Array{Float64,1}
    weights::Array{Float64,1}
    mdd::Float64
    ## efficient sample size and resampling
    nresamp::Int
    ## mutation via block rwmh
    c::Float64
    accept::Float64
end
