##initialize SMC sampler using prior draws
function init_smc(particles::Matrix{Float64},logprior::Vector{Float64},
                loglh::Vector{Float64};parallel::Bool=true,c::Float64=0.5)
    n_part = size(particles,1)
    S_init = SMCSampler(parallel, particles,logprior,
             loglh,1/n_part*ones(n_part),0.0,0,c,0.25)
    return S_init
end

##initialize SMC sampler using previous results, restart from recursion k
function load_smc_results(k::Int;parallel::Bool=true)
    filename1 = savepath("smcsave1.csv")
    save1 = convert(Array{Float64,2},Matrix(CSV.read(filename1)))
    save2 = CSV.read(savepath("smcsave2.csv"))
    save3 = CSV.read(savepath("smcsave3.csv"))
    mdd = sum(log.(save3[1:(k-1),1]))
    save4 = CSV.read(savepath("smcsave4.csv"))
    S_init = SMCSampler(parallel, save1, save2[:,2],save2[:,3],save2[:,1], mdd, save4[1,1],save4[2,1],save4[3,1])
    return S_init
end
