__precompile__()
module MySMC
# cd("C:/Users/29345/Desktop/MySMC")
using Random, LinearAlgebra, Distributions
using Printf, Distributed, CSV, DataFrames
using DataStructures: SortedDict, insert!, ForwardOrdering, OrderedDict

const VERBOSITY = Dict(:none => 0, :low => 1, :high => 2)

include("SMC_types.jl")
include("SMC_IO.jl")
include("systematic_resampling.jl")
include("mutation_blockmh.jl")
include("SMC_initialize.jl")
include("SMC_algorithm.jl")

export
    SMCSampler, init_smc, load_smc_results,
    smc, systematic_resampling, mutation_blockmh,
    savepath

end
