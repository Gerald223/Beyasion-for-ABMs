##resampling step in SMC
function systematic_resampling(weight::Vector)
    npart = length(weight)
    cweight = cumsum(weight)
    uu = zeros(npart,1)
    csi=rand()
    for j=1:npart
        uu[j] = (j-1+csi)/npart
    end
    indx = zeros(Int,npart)
    ## judge which interval u[i] drops into
    for i = 1:npart
        j = if i==1
                1
            else
                indx[i-1]
            end  #initialize j for speed
        while j <= npart
            if uu[i] < cweight[j]
                break
            end
            j += 1
        end
        indx[i] = j
    end
    return indx
end
