﻿## mutation by Random-Walk
function RWMH(mu::Vector{Float64},Sigma::Matrix{Float64};c::Float64=1.0)
    U, E, V = svd(Sigma)
    cov_mat = U * Diagonal(sqrt.(E))
    return mu .+ c*cov_mat*randn(length(mu))
end

## run block-rwmh algorithm for each particle
function mutation_blockmh(s::SMCSampler, pri::Function,lh::Function,Φn::Float64,
                  R::Matrix{Float64},b::Vector{Float64},j::Int; n_blocks::Int=1)
    n_param = size(s.particles,2)
    df = DataFrame(x=1:n_param, y=b)
    P_Ind = sort(df,:y)[:,1]
    k = Int(round(n_param/n_blocks))
    ind_accept =0
    ## loop over blockly updating
    for i = 1:n_blocks
        p0 = s.particles[j,:]
        prior0 = s.logprior[j]
        l0 = s.loglh[j]
        # block-updating of parameters
        p_Ind = if i < n_blocks
                   sort(P_Ind[(k*i-k+1):k*i])
                else
                   sort(P_Ind[(k*i-k+1):end])
                end
        px_draw = RWMH(p0[p_Ind], R[p_Ind,p_Ind], c=s.c)
        px = copy(p0)
        px[p_Ind] = px_draw
        # use the blocking-updated parameter px to compute lx and postx
        priorx = pri(px)
        lx = lh(px)
        # accept rate
        rval = rand()
        α = exp((priorx-prior0)+Φn*(lx-l0))
        # Accept/Rejec
        if rval < α # (update this particle with the new draw)
            s.particles[j,:]  = px
            s.logprior[j] = priorx
            s.loglh[j]  = lx
            ind_accept += 1
        end
    end # of block-updating
    return ind_accept
end
