__precompile__()
# module
module MyMCMC
using Random, LinearAlgebra, Distributions
using Printf, Distributed, CSV, DataFrames
using DataStructures: SortedDict, insert!, ForwardOrdering, OrderedDict

const VERBOSITY = Dict(:none => 0, :low => 1, :high => 2)

include("MCMC_types.jl")
include("MCMC_initialize.jl")
include("MCMC_algorithm.jl")

export
    MCMCsampler, init_mcmc,mcmc
end

