function init_mcmc(particles,logprior,loglh,c)
    # accept1=1
    S_init = MCMCsampler(particles,logprior,loglh,c,1)
    return S_init
end
