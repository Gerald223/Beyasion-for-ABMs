function mcmc(n::Int,λ::Float64,pri::Function,lh::Function,S::MCMCsampler,target,m)
        # accept is to adjust the accept rate around the target, 
        # if we don't want to calculate the MLE and information matrix
        # S:n*1
        # see the accept rate finally
        # burn-in
        result=zeros(n,9)
        result[1,:]=S.particles
        acc=0
    for i=2:n
        #S.c=1
        S.c = S.c *(0.95+0.10*exp(16*(S.accept-target))/(1+exp(16*(S.accept-target))))
        c=rand(Normal(),9)
        new=S.particles+S.c*c
        prior0 = S.logprior
        lh0 = S.loglh
        pri_new=pri(new)
        lh_new=lh(new)
        alpha=exp((pri_new-prior0)+(lh_new-lh0))
        #println(S.c)
        rval = rand()
        if rval < alpha # (update this particle with the new draw)
            S.particles  = new
            S.logprior = pri_new
            S.loglh  = lh_new
            S.accept=min(1,alpha)
            acc+=1
        else
            S.accept=max(0,alpha)
        end
        println(alpha)
        result[i,:]=S.particles
        end
    mu=mean(result[m:n,:],dims=1)
    sigma2=var(result[m:n,:],dims=1) 
    posterior=zeros(2,9)
    posterior[1,:]=mu
    posterior[2,:]=sigma2
    # 总体接受率
    println(acc/n)
    return posterior
end