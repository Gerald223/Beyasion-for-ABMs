mutable struct MCMCsampler
    ## parallel computing
    ## particle draws
    particles::Array{Float64,1}
    logprior::Float64
    loglh::Float64
    # tuning parameter
    c::Float64
    accept::Float64
end

